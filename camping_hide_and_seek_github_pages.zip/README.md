# 露營躲貓貓

這是一個使用 GitHub Pages 發布的單頁活動網站。

## 遊戲
營區藏有 8 個躲貓貓小人，賓客掃描 QR Code 後進入網站，找到實體小人後，可在網站上點亮對應的小人，集滿 8/8 後領取小禮物。

## 發布
將 `index.html` 放在 GitHub repository 的最上層，並在 Settings → Pages → Build and deployment 設定為 Deploy from a branch，選 `main` / `/(root)`。
